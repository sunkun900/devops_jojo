from django.contrib import admin

from ops.models import FgcBitopImgAliossUpdateInfoModel, MkAliossUpdateInfoModel, SidAliossUpdateInfoModel, \
    UIAliossUpdateInfoModel


admin.site.register(FgcBitopImgAliossUpdateInfoModel)
admin.site.register(MkAliossUpdateInfoModel)
admin.site.register(SidAliossUpdateInfoModel)
admin.site.register(UIAliossUpdateInfoModel)
