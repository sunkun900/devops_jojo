# 介绍 
基于drf，目前以django自带admin为管控  
做了一部分的动态路由  
支持 部分cloudflare功能，本地证书自动更新(通过cf添加txt记录)功能，阿里云oss上传功能  
<font color=red>留作个人归档</font>
