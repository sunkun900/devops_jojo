<template>
    <div class="group-list-container">
        组列表
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>

</style>
